////////////////////////////////////////////////////////////////////////////
// SPECIAL EFFECTS INITIALIZATION
// Initializes special effects

var effectsArray = new Array();
var effectNum;


function stepEffects() {
	if (effectNum != null) {
		if (effectsArray[effectNum]) {
			effectsArray[effectNum];
			effectNum++;
		}
		else {
			purgeEffects();
		}
	}
}


////////////////////////////////////////////////////////////////////////////
// FADE IN/FADE OUT OVERLAY
// Used to make window fade in/fade away - opacity change

var fadeIncrement = 20;
var fadeSpeed = 5;

function fadeOut(target,origOp,newOp) {

	var targelem = document.getElementById(target);
	var oldopacity = origOp;
	var newopacity = newOp;
	var targopacity = eval(oldopacity - fadeIncrement);
	
	if ((newopacity < oldopacity) && (targopacity > 0)) {
		if (targelem.filters) { targelem.style.filter = ' alpha(opacity=' + targopacity + ')'; } 
		else { targelem.style.opacity = targelem.style.MozOpacity = targopacity / 100; }
		var oldopacity = targopacity; 
		var fadeOutTimer = window.setTimeout('fadeOut(\''+target+'\','+oldopacity+','+newopacity+')', fadeSpeed);
	} else {
		if (targelem.filters) { targelem.style.filter = 'alpha(opacity=' + newopacity + ')'; }
		else { targelem.style.opacity = targelem.style.MozOpacity = newopacity / 100; }
		targelem.style.display = "none";
		clearTimeout(fadeOutTimer);
		
		// sequence effect
		if (!fadeOutTimer) { stepEffects(); }
	}
}

function fadeIn(target,origOp,newOp) {

	var targelem = document.getElementById(target);
	var oldopacity = origOp;
	var newopacity = newOp;
	var targopacity = eval(oldopacity + fadeIncrement);
	
	if ((oldopacity < newopacity) && (targopacity < newopacity)) {
		if (targelem.filters) { targelem.style.filter = 'alpha(opacity=' + targopacity + ')';} 
		else { targelem.style.opacity = targelem.style.MozOpacity = targopacity / 100; }
		var oldopacity = targopacity; 
		var fadeInTimer = window.setTimeout('fadeIn(\''+target+'\','+oldopacity+','+newopacity+')', fadeSpeed);
	} else {
		if (targelem.filters) { targelem.style.filter = 'alpha(opacity=' + newopacity + ')'; }
		else { targelem.style.opacity = targelem.style.MozOpacity = newopacity / 100; }
		targelem.style.display = "block";
		clearTimeout(fadeInTimer);
		
		// sequence effect
		if (!fadeInTimer) { stepEffects(); }
	}
}


////////////////////////////////////////////////////////////////////////////
// CLASS FINDER
// Used to find all the locations of the specified class

function getElementsByClassName(node, classname)
{
    var a = [];
    var re = new RegExp('\\b' + classname + '\\b');
    var els = node.getElementsByTagName("*");
    for(var i=0,j=els.length; i<j; i++)
        if(re.test(els[i].className))a.push(els[i]);
    return a;
}

////////////////////////////////////////////////////////////////////////////
// LEFT AND TOP POSITION FINDER
// Used to find the left and top position of the element

function findPosLeft(obj) {
	var curleft = 0;
	if (obj.offsetParent) {
		curleft = obj.offsetLeft
		while (obj = obj.offsetParent) {
			curleft += obj.offsetLeft
		}
	}
	return curleft;
}

function findPosTop(obj) {
	var curtop = 0;
	if (obj.offsetParent) {
		curtop = obj.offsetTop
		while (obj = obj.offsetParent) {
			curtop += obj.offsetTop
		}
	}
	return curtop;	
}

////////////////////////////////////////////////////////////////////////////
// CART OVERLAY OPENER
// Used to open the cart overlay

var isIE = (navigator.userAgent.toLowerCase().indexOf("msie") > 0) ? true : false;

cartOverlay = function(id, area, layerId) {
	
	var cart = getElementsByClassName(document, id);
	var left = findPosLeft(cart[0]);
	var top = findPosTop(cart[0]);
	var layer = document.getElementById(layerId);
	
	var carticon = document.getElementById(id);
	carticon.style.display = 'block';
	carticon.style.left = (left - 15) + "px";
	carticon.style.top = (top - 5) + "px";
	
	layer.style.top = findPosTop(cart[0]) + 25 + "px";
	clientw = cart[0].parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.clientWidth;
	clientw = clientw / 2;	
	clientw = clientw - 468;
	layer.style.left = clientw + "px";
	layer.style.display = 'block';	
	//layer.style.height = "0px";
	
	cover = getElementsByClassName(document, 'cover');
	cover[0].style.top = "0px";
	cover[0].style.left = "0px";
	cover[0].style.display = "block";

	var page = getElementsByClassName(document, area);
	page[0].style.display = "block";
	page[0].style.height = "0px";
	
	//rollDown(layerId, 0, 600);
	fadeIn(layerId, 0, 100);
}

////////////////////////////////////////////////////////////////////////////
// CART OVERLAY CLOSER
// Used to close the cart overlay


hideCart = function(layerId) {
	//rollUp(layerId, 600, 0);
	fadeOut(layerId, 100, 0);
	var idToHide = document.getElementById(layerId);
	//idToHide.style.display = 'none';
	var carticon = document.getElementById('cart');
	carticon.style.display = 'none';	
	var myaccount = document.getElementById('myaccount');
	myaccount.style.display = 'none';	

	cover = getElementsByClassName(document, 'cover');
	cover[0].style.display = 'none';
	
	var page = getElementsByClassName(document, "page");
	for (var i=0; i<page.length; i++) {
		//page[i].style.display = "none";	
	}
	
	var account = getElementsByClassName(document, "myact");
	for (var i=0; i<account.length; i++) {
		//account[i].style.display = "none";
	}
	
}

////////////////////////////////////////////////////////////////////////////
// DIV POP UP'S
// Opens and closes up a non-browser pop up window

openWindow = function(id, position) {
	var popup = document.getElementById(id);
	var left = findPosLeft(position);
	var top = findPosTop(position);
	popup.style.left = left + "px";
	popup.style.top = top + "px";
	popup.style.display = 'block';
}

closeWindow = function(id) {
	var popup = document.getElementById(id);
	popup.style.display = 'none';
}

////////////////////////////////////////////////////////////////////////////
// CHECKS ALL CHECKBOXES
// Enables all check boxes in the table

checkItems = function(inputBox) {
	var box = document.getElementsByName(inputBox);
	if (box[0].checked == true) {
		for (var i=1; i < box.length; i++) {
			box[i].checked = true;
		}
	} else {
		for (var i=1; i < box.length; i++) {
			box[i].checked = false;
		}
	}
}

////////////////////////////////////////////////////////////////////////////
// BUTTONS ENABLES
// Enables all buttons if one or more check boxes are checked


buttonsEnabler = function() {
	var enabled = false;
	var total = 1;
	var box = document.getElementsByName('box');
	for (var i=1; i<box.length; i++) {
		if (box[i].checked == true) {
			total--;
		} else {
			total++;
		}
	}
	
	enabled = (total < box.length)? true:false;
	
	var buttons = getElementsByClassName(document, 'button');
	
	for (var i=0; i<3; i++) {
		if ((buttons[i].className == "button disabled") && (enabled)) {
			buttons[i].className = "button enabled";
		}
		if ((buttons[i].className == "button enabled") && (!enabled)) {
			buttons[i].className = "button disabled";
		}
	}
	
}


if (window.addEventListener)
window.addEventListener("load", buttonsEnabler, false)
else if (window.attachEvent)
window.attachEvent("onload", buttonsEnabler)

////////////////////////////////////////////////////////////////////////////
// ACCORDION EFFECT
// Does the accordion effect without the special effects


accordion = function(section, body, num) {
	var sections = getElementsByClassName(document, section);
	sections[num].childNodes[1].childNodes[1].className = 'arrowdown headertext';
	var bodies = getElementsByClassName(document, body);	
	bodies[num].style.display = 'block';
	
	for (var i=0; i < sections.length; i++) {
		if (i != num) {
			sections[i].childNodes[1].childNodes[1].className = 'arrowright headertext';
			bodies[i].style.display = 'none';
		}
	}
}

accordionLoad = function() {
	accordion('section', 'body', 0);
}

if (window.addEventListener)
window.addEventListener("load", accordionLoad, false)
else if (window.attachEvent)
window.attachEvent("onload", accordionLoad)


////////////////////////////////////////////////////////////////////////////
// NEXT AND PREVIOUS OVERLAYS
// Moves the user to the next segment in the overlays


nextPage = function(next, section) {
	var page = getElementsByClassName(document, section);
	page[next].style.display = "none";
	page[next+1].style.display = "block";
	
}

prevPage = function(next, section) {
	var page = getElementsByClassName(document, section);
	page[next-1].style.display = "block";
	page[next].style.display = "none";
}

gotoPage = function(next, section) {
	var page = getElementsByClassName(document, section);
	for (var i=0; i<page.length; i++) {
		if (i != next) {
			page[i].style.display = "none";	
		} else {
			page[i].style.display = "block";
		}
	}
}
